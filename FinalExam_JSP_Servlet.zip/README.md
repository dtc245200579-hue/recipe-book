# Bài kiểm tra cuối module: Quản lý sản phẩm JSP & Servlet

## Công nghệ
- Java 17
- Maven
- Jakarta Servlet/JSP (Tomcat 10.1 trở lên)
- MySQL 8
- JDBC

## 1. Chuẩn bị
Cài JDK 17, Maven, MySQL và Apache Tomcat 10.1+. Mở thư mục dự án trong VS Code.

## 2. Tạo cơ sở dữ liệu
Mở MySQL Workbench hoặc MySQL Terminal, chạy toàn bộ file `database.sql`. File tạo database `product_management`, bảng `products` và 3 sản phẩm mẫu.

## 3. Cấu hình kết nối MySQL
Mở `src/main/java/vn/edu/finalexam/util/DBConnection.java` và sửa `DB_USER`, `DB_PASSWORD` cho đúng tài khoản MySQL của bạn. Không nộp mật khẩu thật lên kho mã nguồn công khai.

Mặc định:
- Host: `localhost:3306`
- Database: `product_management`
- User: `root`
- Password: để trống (hãy sửa theo máy của bạn)

## 4. Build dự án
Mở Terminal tại thư mục có `pom.xml`, chạy:
```bash
mvn clean package
```
Nếu build thành công, file WAR được tạo tại `target/product-management.war`.

## 5. Chạy bằng Tomcat
1. Sao chép `target/product-management.war` vào thư mục `webapps` của Tomcat 10.1.
2. Khởi động Tomcat.
3. Mở `http://localhost:8080/product-management/products`.

Có thể cấu hình Tomcat trong VS Code bằng extension Community Server Connectors, hoặc triển khai WAR thủ công như trên.

## Chức năng
- Danh sách sản phẩm: `/products`
- Thêm: nút “Thêm sản phẩm”
- Sửa: nút “Sửa” ở từng dòng
- Xóa: nút “Xóa”, có hộp thoại xác nhận

## Ghi chú
Dự án sử dụng `jakarta.servlet.*`, vì vậy cần Tomcat 10.1+. Nếu lớp học yêu cầu Tomcat 9, cần đổi dependency và import sang `javax.servlet.*`.
