<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title><c:out value="${pageTitle}"/></title><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<main class="container form-container">
  <a class="back-link" href="${pageContext.request.contextPath}/products">← Quay lại danh sách</a>
  <section class="panel form-panel">
    <p class="eyebrow">THÔNG TIN SẢN PHẨM</p><h1><c:out value="${pageTitle}"/></h1>
    <p class="muted">Nhập đầy đủ thông tin bên dưới.</p>
    <c:if test="${not empty error}"><div class="notice error"><c:out value="${error}"/></div></c:if>
    <form method="post" action="${pageContext.request.contextPath}/products" class="product-form">
      <c:choose>
        <c:when test="${not empty product}"><input type="hidden" name="action" value="update"><input type="hidden" name="id" value="${product.id}"></c:when>
        <c:otherwise><input type="hidden" name="action" value="insert"></c:otherwise>
      </c:choose>
      <label for="name">Tên sản phẩm <span>*</span></label>
      <input id="name" name="name" type="text" maxlength="150" required value="<c:out value='${product.name}'/>" placeholder="Ví dụ: Bàn phím cơ">
      <div class="field-row">
        <div><label for="price">Giá (VNĐ) <span>*</span></label><input id="price" name="price" type="number" min="0" step="0.01" required value="<c:out value='${product.price}'/>" placeholder="0"></div>
        <div><label for="quantity">Số lượng <span>*</span></label><input id="quantity" name="quantity" type="number" min="0" step="1" required value="<c:out value='${product.quantity}'/>" placeholder="0"></div>
      </div>
      <div class="form-actions"><a class="button" href="${pageContext.request.contextPath}/products">Hủy</a><button class="button primary" type="submit">Lưu sản phẩm</button></div>
    </form>
  </section>
</main>
</body></html>
