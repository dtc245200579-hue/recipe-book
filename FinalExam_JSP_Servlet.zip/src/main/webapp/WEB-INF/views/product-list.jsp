<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Quản lý sản phẩm</title><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<main class="container">
  <header class="page-header">
    <div><p class="eyebrow">BÀI KIỂM TRA CUỐI MODULE</p><h1>Quản lý sản phẩm</h1><p class="muted">Danh sách sản phẩm trong hệ thống</p></div>
    <a class="button primary" href="${pageContext.request.contextPath}/products?action=new">＋ Thêm sản phẩm</a>
  </header>
  <c:if test="${param.message == 'success'}"><div class="notice success">Lưu sản phẩm thành công.</div></c:if>
  <c:if test="${param.message == 'deleted'}"><div class="notice success">Đã xóa sản phẩm.</div></c:if>
  <section class="panel">
    <div class="table-wrap"><table>
      <thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá (VNĐ)</th><th>Số lượng</th><th>Thao tác</th></tr></thead>
      <tbody>
      <c:forEach var="p" items="${products}">
        <tr>
          <td><span class="id-tag">#<c:out value="${p.id}"/></span></td>
          <td class="product-name"><c:out value="${p.name}"/></td>
          <td><c:out value="${p.price}"/></td><td><c:out value="${p.quantity}"/></td>
          <td class="actions">
            <a class="button small" href="${pageContext.request.contextPath}/products?action=edit&id=${p.id}">Sửa</a>
            <form method="post" action="${pageContext.request.contextPath}/products" onsubmit="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${p.id}">
              <button class="button small danger" type="submit">Xóa</button>
            </form>
          </td>
        </tr>
      </c:forEach>
      <c:if test="${empty products}"><tr><td colspan="5" class="empty">Chưa có sản phẩm nào. Hãy thêm sản phẩm đầu tiên.</td></tr></c:if>
      </tbody>
    </table></div>
    <div class="table-footer">Tổng số sản phẩm: <strong><c:out value="${products.size()}"/></strong></div>
  </section>
  <footer>Ứng dụng JSP · Servlet · JDBC · MySQL</footer>
</main>
</body></html>
