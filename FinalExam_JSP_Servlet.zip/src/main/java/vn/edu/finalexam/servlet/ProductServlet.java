package vn.edu.finalexam.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.edu.finalexam.dao.ProductDAO;
import vn.edu.finalexam.model.Product;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        try {
            if ("new".equals(action)) {
                request.setAttribute("pageTitle", "Thêm sản phẩm");
                request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
            } else if ("edit".equals(action)) {
                showEditForm(request, response);
            } else {
                request.setAttribute("products", productDAO.findAll());
                request.getRequestDispatcher("/WEB-INF/views/product-list.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException("Không thể truy vấn cơ sở dữ liệu.", e);
        }
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = parseId(request.getParameter("id"));
        Product product = productDAO.findById(id);
        if (product == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm.");
            return;
        }
        request.setAttribute("product", product);
        request.setAttribute("pageTitle", "Sửa sản phẩm");
        request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        try {
            if ("insert".equals(action) || "update".equals(action)) {
                String name = request.getParameter("name");
                String priceText = request.getParameter("price");
                String quantityText = request.getParameter("quantity");

                if (name == null || name.trim().isEmpty()) {
                    forwardWithError(request, response, "Tên sản phẩm không được để trống.", action);
                    return;
                }

                BigDecimal price;
                int quantity;
                try {
                    price = new BigDecimal(priceText);
                    quantity = Integer.parseInt(quantityText);
                    if (price.signum() < 0 || quantity < 0) {
                        forwardWithError(request, response, "Giá và số lượng phải lớn hơn hoặc bằng 0.", action);
                        return;
                    }
                } catch (Exception ex) {
                    forwardWithError(request, response, "Giá hoặc số lượng không hợp lệ.", action);
                    return;
                }

                Product product = new Product(name.trim(), price, quantity);
                if ("insert".equals(action)) {
                    productDAO.insert(product);
                } else {
                    product.setId(parseId(request.getParameter("id")));
                    if (!productDAO.update(product)) {
                        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm.");
                        return;
                    }
                }
                response.sendRedirect(request.getContextPath() + "/products?message=success");
            } else if ("delete".equals(action)) {
                productDAO.delete(parseId(request.getParameter("id")));
                response.sendRedirect(request.getContextPath() + "/products?message=deleted");
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Thao tác không hợp lệ.");
            }
        } catch (SQLException e) {
            throw new ServletException("Không thể cập nhật cơ sở dữ liệu.", e);
        } catch (IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID sản phẩm không hợp lệ.");
        }
    }

    private void forwardWithError(HttpServletRequest request, HttpServletResponse response,
                                  String error, String action) throws ServletException, IOException, SQLException {
        request.setAttribute("error", error);
        request.setAttribute("pageTitle", "insert".equals(action) ? "Thêm sản phẩm" : "Sửa sản phẩm");
        if ("update".equals(action)) {
            Product product = new Product(parseId(request.getParameter("id")),
                request.getParameter("name"), safePrice(request.getParameter("price")),
                safeQuantity(request.getParameter("quantity")));
            request.setAttribute("product", product);
        }
        request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
    }

    private BigDecimal safePrice(String value) {
        try { return new BigDecimal(value); } catch (Exception e) { return BigDecimal.ZERO; }
    }
    private int safeQuantity(String value) {
        try { return Integer.parseInt(value); } catch (Exception e) { return 0; }
    }
    private int parseId(String value) {
        int id = Integer.parseInt(value);
        if (id <= 0) throw new IllegalArgumentException("ID phải lớn hơn 0");
        return id;
    }
}
